import java.util.ArrayList;
import java.util.List; 
 
class Cliente {
    private String fone;
    private String id;
    
    public Cliente (String fone, String id){
        this.fone = fone;
        this.id = id;
    }
    
    public String getFone() {
        return this.fone;
    }
    public String getId() {
        return this.id;
    }
    public void setFone(String fone) {
        this.fone = fone;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String toString (){
        return fone + ":" + id;
    }
 }