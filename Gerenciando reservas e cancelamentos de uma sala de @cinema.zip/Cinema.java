import java.util.ArrayList;
import java.util.List; 
 
class Cinema {
    private int num_Cadeiras;
    private List<Cliente> cadeiras;
    // private Cliente[] cadeiras;
    
    public Cinema(int num_cadeiras) {
        this.num_Cadeiras = num_cadeiras;
        cadeiras = new ArrayList<>();
        for (int i = 0; i < num_Cadeiras; i++) {
            cadeiras.add(null);
        }
        // cadeiras = new Cliente[num_Cadeiras];
    }
    
    public int procurar(String nome) {
        for (int i = 0; i < num_Cadeiras; i++) {
            if(cadeiras.get(i) != null) {
                if (cadeiras.get(i).getFone().equals(nome) ) {
                    return i;
                }
            }
        }
        
        return -1;
    }
    public boolean verificarIndice(int indice) {
        for (int i = 0; i < num_Cadeiras; i++) {
            if (indice < num_Cadeiras) {
                return true;
            }
        }
        return false;
    }
    public boolean reservar(String nome, String fone, int ind) {
        if (verificarIndice(ind)) {
            if (cadeiras.get(ind) != null) {
                IO.println("fail: cadeira ja esta ocupada");
                return false;
            }
            if (procurar(nome) != -1) {
                IO.println("fail: cliente ja esta no cinema");
                return false;
            }
            //cria o cliente e coloca na cadeira
            cadeiras.set(ind, new Cliente(nome, fone));
            return true;
        }
        IO.println("fail: cadeira nao existe");
        return false;
    }
    public void cancelar(String nome) {
        int num = procurar(nome);
        if (num >= 0) {
            cadeiras.set(num, null);
        }
        else {
            IO.println("fail: cliente nao esta no cinema");
        }
    }
    public String toString() {
        String txt;
        txt = "[" ;
        for(int i = 0; i < num_Cadeiras; i++) {
            if (cadeiras.get(i) == null) {
                txt += "-";
                if(i < num_Cadeiras - 1) {
                    txt += " "; 
                }
            }
            else {
                txt += cadeiras.get(i).toString();
                if (i < num_Cadeiras - 1) {
                    txt += " ";
                }
            }
        }
        txt += "]";
        return txt;
    }
}