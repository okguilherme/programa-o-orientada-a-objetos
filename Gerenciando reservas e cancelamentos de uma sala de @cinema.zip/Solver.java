class Solver {
    public static void main (String[] args) {
         Cinema cinema = new Cinema(0);

         while (true) {
             String[] line = IO.inputPartsPrintingLine();

             if      ( line[0].equals("end")    )  { break;                                                                               }
             else if ( line[0].equals("show")   )  { IO.println( cinema.toString() );                                                     }
             else if ( line[0].equals("init")   )  { cinema = new Cinema(IO.strToInt(line[1]));                                       }
             else if ( line[0].equals("reservar")) { cinema.reservar(line[1], line[2], IO.strToInt(line[3]) );  }
             else if ( line[0].equals("cancelar")) { cinema.cancelar( line[1] );                                                                     }
             //else if ( line[0].equals("finish")  ) { mercantil.Finalizar(IO.strToInt(line[1]));                                                                  }
             else                                  { IO.println("fail: comando invalido");                                                }
         }
    }
}