class SavingsAccount extends Account{
    private double monthlyFee = 0.01;
    
    public SavingsAccount (String clientId, String typeId) {
        super ( clientId, typeId ); 
    }
    
    public void updateMonthly() {
        this.balance += (balance * this.monthlyFee);
    }
}