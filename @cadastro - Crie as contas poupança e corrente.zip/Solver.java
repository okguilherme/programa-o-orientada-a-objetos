import java.util.*;
import java.text.DecimalFormat;

class Client {
    private String clientId; // name
    private ArrayList<Account> accounts;

    public Client( String clientId ) {
        this.clientId = clientId;
        accounts = new ArrayList<>();
    }

    public void addAccount( Account acc ) {
        accounts.add(acc);
    }

    public ArrayList<Account> getAccounts() {
        return this.accounts;
    }
    public String getClientId() {
        return this.clientId;
    }

    @Override
    public String toString() {
        String txt = "";
    
        txt += this.clientId + " [" ;
        
        for (int i = 0; i < accounts.size(); i++) {
            txt += accounts.get(i).getAccId();
            if (i < accounts.size() - 1) {
                txt += ", ";
            }
        }
        txt += "]\n";
        
        return txt;
    }
}

abstract class Account {
    protected double balance; // saldo
    private static int nextAccountId = 0;
    protected int accId; // id da conta
    protected String clientId;
    protected String typeId; // tipo da conta [CC, CP]

    public Account( String clientId, String typeId ) {
        this.clientId = clientId;
        this.typeId = typeId;
        accId = nextAccountId;
        nextAccountId ++;
        
    }

    public void deposit( double value ) {
        this.balance += value;
    }
    public void withdraw( double value ) throws Exception {
        if (this.balance - value >= 0) {
            this.balance -= value;
        }
        else {
            //System.out.println("fail: saldo insuficiente");
            throw new MsgException("fail: saldo insuficiente");
        }
    }
    // public void transfer( Account other, double value ) {
    //     if ( this.balance - value >= 0 ) {
    //         other.deposit(value);
    //     }
    // }

    @Override
    public String toString() {
        String txt = "";
        DecimalFormat d = new DecimalFormat("0.00"); //double x = 4.3; System.out.println( d.format(x) ); //4.30
        txt = this.accId + ":" + clientId + ":" + d.format(this.balance) + ":" + this.typeId + "\n";
        return txt;
    }

    public double getBalance() {
        return this.balance;
    }
    public int getAccId() {
        return this.accId;
    }
    public String getClientId() {
        return this.clientId;
    }
    public String getTypeId() {
        return this.typeId;
    }

    // método abstrato que realiza a atualização mensal da conta
    // o método deve ser implementado nas subclasses :
    public abstract void updateMonthly(); 
    
}

class Agency {
    private Map<Integer, Account> accounts;
    private Map<String, Client> clients;

    

    public Agency() {
        this.accounts = new HashMap<Integer,Account>();
        // this.clients = new HashMap<String,Client>();
        this.clients = new LinkedHashMap<String,Client>();
    }

    private Account getAccount(int accountId) {
        Account ob = accounts.get(accountId);
        if (ob != null) {
            //System.out.println("tem conta");
            return ob;
        }
        else {
            //System.out.println("nao tem conta");
            return null;
        }
    }
    
    // cria uma conta para o cliente
    // cria um objeto cliente e insere no mapa de clientes
    // cria uma conta corrente e uma conta poupança e insere no mapa de contas
    // faz o vínculo cruzado colocando as contas dentro do objeto do cliente
    public void addClient(String clientId) {
        
        Client cliente = new Client(clientId);
        
        clients.put(clientId, cliente);
        
        Account contac = new CheckingAccount(clientId, "CC");
        Account contap = new SavingsAccount(clientId, "CP");
        
        accounts.put(contac.getAccId(), contac);
        accounts.put(contap.getAccId(), contap);
        
        cliente.addAccount(contac);
        cliente.addAccount(contap);
    }

    // procura pela conta usando o getAccount e realiza a operação de depósito
    // utiliza o método deposit da classe Account
    public void deposit(int accId, double value) {
        Account conta = getAccount( accId );
        conta.deposit( value );
    }

    // procura pela conta e realiza a operação de saque
    // utiliza o método withdraw da classe Account
    public void withdraw(int accId, double value) throws Exception {
        Account conta = getAccount( accId );
        conta.withdraw( value );
        
    }

    // procura pela conta e realiza a operação de transferência
    // utiliza o método transfer da classe Account
    public void transfer(int fromAccId, int toAccId, double value) throws Exception {
        
        Account fromConta = getAccount( fromAccId );
        Account toConta = getAccount( toAccId );
        
        if(getAccount(fromAccId) != null && getAccount(toAccId) != null) {
            fromConta.withdraw( value );
            toConta.deposit( value );
        }
        else {
            //System.out.println("fail: conta nao encontrada");
            throw new MsgException("fail: conta nao encontrada");
        }
    }

    // realiza a operação de atualização mensal em todas as contas
    public void updateMonthly() {
        for (Account conta : accounts.values()) {
            conta.updateMonthly();
        }
    }

    @Override
    public String toString() {
        String s = "- Clients\n";
        for ( Client client : this.clients.values() ) {
            s += client.toString();
        }
        s += "- Accounts\n";
        for ( Account acc : this.accounts.values() ) {
            s += acc;
        }
        return s;
    }
}

public class Solver {
    public static void main(String[] arg) {
        Agency agency = new Agency();

        while (true) {
            String line = input();
            println("$" + line);
            String[] args = line.split(" ");

            try {
                if      (args[0].equals("end"))       { break; }
                else if (args[0].equals("show"))      { print(agency.toString()); }
                else if (args[0].equals("addCli"))    { agency.addClient( args[1] ); }
                else if (args[0].equals("deposito"))  { agency.deposit( (int) number(args[1]), number(args[2]) ); }
                else if (args[0].equals("saque"))     { agency.withdraw( (int) number(args[1]), number(args[2]) ); }
                else if (args[0].equals("transf"))    { agency.transfer( (int) number(args[1]), (int) number(args[2]), number(args[3]) ); }
                else if (args[0].equals("update"))    { agency.updateMonthly(); }
                else                                  { println("fail: comando invalido"); }
            } catch (Exception e) {
                println( e.getMessage() );
            }
        }
    }

    private static Scanner scanner = new Scanner(System.in);
    private static String  input()                { return scanner.nextLine();        }
    private static double  number(String value)   { return Double.parseDouble(value); }
    public  static void    println(Object value)  { System.out.println(value);        }
    public  static void    print(Object value)    { System.out.print(value);          }
}
