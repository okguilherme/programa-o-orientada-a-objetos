class MsgException extends Exception {
    public MsgException(String msg) {
    super(msg);
    }
}