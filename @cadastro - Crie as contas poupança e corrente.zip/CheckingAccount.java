class CheckingAccount extends Account {
    private double monthlyFee = 20;
    
    public CheckingAccount (String clientId, String typeId) {
        super ( clientId, typeId ); 
    }
    
    public void updateMonthly() {
        this.balance -= this.monthlyFee;
    }
}