class Solver {
    public static void main (String[] args) {
        Mercantil mercantil = new Mercantil(1);

        while (true) {
            String[] line = IO.inputPartsPrintingLine();

            if      ( line[0].equals("end")    )  { break;                                                                               }
            else if ( line[0].equals("show")   )  { IO.println( mercantil.toString() );                                                     }
            else if ( line[0].equals("init")   )  { mercantil = new Mercantil(IO.strToInt(line[1]));                                       }
            else if ( line[0].equals("arrive") )  { mercantil.Chegar( new Cliente(line[1]) );  }
            else if ( line[0].equals("call") )    { mercantil.Chamar(IO.strToInt(line[1]));                                                                     }
            else if ( line[0].equals("finish")  ) { mercantil.Finalizar(IO.strToInt(line[1]));                                                                  }
            else                                  { IO.println("fail: comando invalido");                                                }
        }
    }
}