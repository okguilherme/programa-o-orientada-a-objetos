import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Mercantil {
    private List<Cliente> espera;
    private String [] caixa;
    
    public Mercantil(int qtdCaixa) {
        caixa = new String [qtdCaixa];
        espera = new ArrayList<>();
    }
    
    private boolean validarIndice(int indice) {
        if (caixa [indice] == "-----") {
            return true;
        }
    return false;
    }
    
    public void Chegar (Cliente pessoa) {
        espera.add(pessoa);
    }
    public boolean Chamar (int indice) {
        if (!espera.isEmpty()) {
            if (validarIndice(indice)) {
                caixa[indice] = espera.get(0).getNome();
                espera.remove(0);
                return true;
            }
            else {
                IO.println("fail: caixa ocupado");
                return false;
            }
        }
    IO.println("fail: sem clientes");
    return false;
    }
    public void Finalizar(int indice) {
        if (indice < caixa.length) {
            if(!validarIndice(indice)) {
                caixa[indice] = "-----";
            }
            else {
                IO.println("fail: caixa vazio");
            }
        }
        else {
            IO.println("fail: caixa inexistente");
        }
    }
    public boolean Desistir(String desistente) {
        for (int i=0; i <= espera.size(); i++) {
            if (espera.get(i).getNome().equals(desistente)) {
                espera.remove(i);
                return true;
            }
        }
    return false;
    }
    
    public String toString() {
    String texto = "";
    String txt = "";
    
    // Preenche os valores nulos em 'caixa' com "-----"
    for (int i = 0; i < caixa.length; i++) {
        if (caixa[i] == null) {
            caixa[i] = "-----";  
        }
    }
    
    // Constrói a string 'texto' com os valores de 'caixa'
    for (int i = 0; i < caixa.length - 1; i++) {
        texto += caixa[i] + ", ";
    }
    texto += caixa[caixa.length - 1];
    
    // Constrói a string 'txt' com os valores de 'espera'
    if (!espera.isEmpty()) {
        for (int i = 0; i < espera.size() - 1; i++) {
            txt += espera.get(i).getNome() + ", ";
        }
        txt += espera.get(espera.size() - 1).getNome();
    }
    
    return ("Caixas: [" + texto + "]\nEspera: [" + txt + "]");
    
    }
}