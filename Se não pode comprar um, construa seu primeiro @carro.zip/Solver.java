
class Solver {
    public static void main (String[] arg) {
        Carro carro = new Carro();

        while (true) {
            String line = IO.input();
            IO.println("$" + line);
            String[] args = line.split(" ");

            if      (args[0].equals("end"))   { break;                                 }
            else if (args[0].equals("init"))  { carro = new Carro();                   }
            else if (args[0].equals("enter")) { carro.enter();                         }
            else if (args[0].equals("leave")) { carro.leave();                         }
            else if (args[0].equals("drive")) { carro.drive( IO.strToInt(args[1]) );   }
            else if (args[0].equals("fuel"))  { carro.fuel( IO.strToInt(args[1]) );    }
            else if (args[0].equals("show"))  { IO.println( carro.toString() );        }
            else                              { IO.println("fail: comando invalido");  }
        }
    }
}
