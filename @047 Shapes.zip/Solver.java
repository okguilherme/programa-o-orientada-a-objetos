
import java.util.*; // importar todas as classes e interfaces do pacote java.util 
// como : ( import java.util.List; import java.util.ArrayList; .....)

// import java.text.DecimalFormat;

class Point2D {
    public double x;
    public double y;

    public Point2D( double x, double y ) {
        this.x = x;
        this.y = y;
    }

    public double distance( Point2D p ) {
        double cH = this.x - p.x;
        double cV = this.y - p.y;
        return Math.sqrt( cH*cH + cV*cV );
    }

    @Override
    public String toString() {
        return String.format("%.2f", this.x) + ", " + String.format("%.2f", this.y);
    }
}

abstract class Shape {
    public String name;

    public Shape( String name ) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public abstract boolean inside( Point2D p );
    
    public abstract double getArea();
        
    public abstract double getPerimeter();
        

    public String getInfo() {
        //DecimalFormat d = new DecimalFormat("0.00"); //double x = 4.3; System.out.println( d.format(x) ); //4.30
        String txt = "";
        txt = this.name + ": ";
        txt += "A=" + String.format( "%.2f", this.getArea() ) + " ";
        txt += "P=" + String.format( "%.2f",this.getPerimeter() );
        return txt;
    }
    @Override
    public String toString() {
        return "";
    }
}

class Circle extends Shape {
    public Point2D center;
    public double radius;

    public Circle( Point2D center, double radius ) {
        super ("Circ");
        this.center = center;
        this.radius = radius;
    }

    public boolean inside( Point2D p ) {
        return false;
    }
    public double getArea() {
        return Math.PI * this.radius * this.radius;
    }
    public double getPerimeter() {
        return 2*Math.PI * this.radius;
    }

    @Override
    public String toString() {
        //DecimalFormat d = new DecimalFormat("0.00"); 
        //double x = 4.3; System.out.println( d.format(x) ); //4.30
        //return "Circ" + ": " + "C=(" + d.format(this.center.x) + ", " + d.format(this.center.y) + "), R=" + d.format(this.radius);
        return "Circ" + ": " + "C=(" + this.center + "), R=" + String.format("%.2f", this.radius);
    }
}

class Rectangle extends Shape {
    public Point2D p1;
    public Point2D p2;

    public Rectangle( Point2D p1, Point2D p2 ) {
        super("Rect");
        this.p1 = p1;
        this.p2 = p2;
    }

    public boolean inside( Point2D p ) {
        return false;
    }
    public double getArea() {
        double base = this.p2.x - this.p1.x ; 
        double altura = this.p2.y - this.p1.y ;
        return base * altura;
    }
    
    public double getPerimeter() {
        double Perimeter = 2*(this.p2.x - this.p1.x) + 2*(this.p2.y - this.p1.y);
        return Perimeter;
    }

    @Override
    public String toString() {
        //DecimalFormat d = new DecimalFormat("0.00"); //double x = 4.3; System.out.println( d.format(x) ); //4.30
        return "Rect: P1=(" + this.p1 + ") P2=(" + this.p2 + ")";
    }
}

public class Solver {
    public static void main(String[] arg) {
        Circle circle = new Circle( new Point2D(0, 0), 0);
        Rectangle rect = new Rectangle( new Point2D(0, 0), new Point2D(0,0) );
        ArrayList<Shape> figuras = new ArrayList<>(); 
        
        
        while (true) {
            String line = input();
            println("$" + line);
            String[] args = line.split(" ");

            if      (args[0].equals("end"))       { break; }
            else if (args[0].equals("circle"))    { figuras.add( new Circle( new Point2D( number(args[1]), number(args[2]) ), number(args[3]) ) ); }
            else if (args[0].equals("rect"))      { figuras.add( new Rectangle( new Point2D( number(args[1]), number(args[2]) ), new Point2D( number(args[3]), number(args[4]) ) ) ); }
            else if (args[0].equals("show"))      { showAll(figuras); }
            else if (args[0].equals("info"))      { infoAll(figuras); }
            else                                { println("fail: comando invalido"); }
        }
    }

    private static Scanner scanner = new Scanner(System.in);
    private static String  input()                { return scanner.nextLine();        }
    private static double  number(String value)   { return Double.parseDouble(value); }
    public  static void    println(Object value)  { System.out.println(value);        }
    public  static void    print(Object value)    { System.out.print(value);          }
    public  static void showAll( ArrayList<Shape> shapes ) { for ( Shape s : shapes ) println( s ); }
    public  static void infoAll( ArrayList<Shape> shapes ) { for ( Shape s : shapes ) println( s.getInfo() ); }
}
