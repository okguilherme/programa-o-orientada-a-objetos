import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

class Trampoline {
    private List<Kid> playing;
    private List<Kid> waiting;
            
    public Trampoline() {
        playing = new ArrayList<>();
        waiting = new ArrayList<>();
    }
    public static Kid removeFromList (String name, List<Kid> list) {
        for(int i = 0; i <= list.size()-1; i++){    
            if (name.equals(list.get(i).getName())) {
                return list.remove(i);
            }
        }
        return null;
    }
    public void Arrive (Kid kid) {
        waiting.add(kid);
    }
    
    public void Enter() {
        if (!waiting.isEmpty()) { // verificar se a lista waiting está vazia
            Kid kid = waiting.remove(0); // Remove o último Kid de waiting
            playing.add(0, kid); // Adiciona o Kid no início de playing
            Collections.reverse( playing);
        }
        else {
            IO.println("Nenhum Kid está esperando.");
        }
    }
    public void leave() {
         if (!playing.isEmpty()) {
             Kid kid = playing.remove(0);
             waiting.add(kid);
         }
    }
    
    public Kid removeKid(String name) {
        Kid kid = removeFromList(name, waiting);
        Kid kid2 = removeFromList(name, playing);
        
        if (kid != null) {
            return kid;
        }
        else if (kid2 != null) {
            return kid2;
        }
        else {
            return null;
        }
    }
    
    public String toString() {
        String string = "[";
        for (int i = waiting.size()-1; i >= 0 ; i--) {
            
            if (!waiting.isEmpty()) {
                string += waiting.get(i);
                if(i > 0) {
                    string += ", " ;
                }
            }
        }
        
        string += "] => [";
        
        for (int i = playing.size()-1; i >= 0 ; i--) {
            
            if (!playing.isEmpty()) {
                string += playing.get(i);
                if(i > 0) {
                    string += ", " ; 
                }
            }
        }
        string += "]";
        return string;
    }
}