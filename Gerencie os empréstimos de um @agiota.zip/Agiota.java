import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Comparador implements Comparator<Client> {
    public int compare(Client c1, Client c2) {
        // if (c1.getLimite() < c2.getLimite()) {
        //     return -1;
        // }
        // else if (c1.getLimite() > c2.getLimite()){
        //     return 1;
        // }
        // else {
        //     return 0;
        // }
        
        return c1.getName().compareTo(c2.getName());
    }
}

class Agiota {
    private ArrayList<Client> aliveList;
    private ArrayList<Client> deathList;
    private ArrayList<Operation> aliveOper;
    private ArrayList<Operation> deathOper;

    private int searchClient(String name) {
        for (int i = 0; i < this.aliveList.size(); i++) {
            Client cliente = this.aliveList.get(i);
            if (cliente.getName().equals(name)) {
                return i;
            }
        }
        return -1;
    }
    private void pushOperation(Client client, String name, Label label, int value) {
        Operation oper = new Operation( name, label, value );
        this.aliveOper.add( oper );
        client.addOperation( oper );
    }

    private void sortAliveList() {
        //this.aliveList.sort(); //para inteiros
        // Collections.sort (this.aliveList); //para inteiros
        
        this.aliveList.sort(new Comparador());
        // this.aliveList.sort( new Comparator<Client>() {
        //     public int compare(Client c1, Client c2) {
        //         return c1.getName().compareTo(c2.getName());
        //         // if (c1.getLimite() < c2.getLimite()) return -1;
        //         // else if (c1.getLimite() > c2.getLimite()) return 1;
        //         // else return 0;
        //     }
        // });

        // Collections.sort (this.aliveList, new Comparator<Client>() {
        //     public int compare(Client c1, Client c2) {
        //         return c1.getName().compareTo(c2.getName());
        //     }
        // });

        // Collections.sort (this.aliveList, new Comparador());
    }

    public Agiota() {
        this.aliveList = new ArrayList<>();
        this.deathList = new ArrayList<>();
        this.aliveOper = new ArrayList<>();
        this.deathOper = new ArrayList<>();
    }

    public Client getClient(String name) {
        for (Client cliente : this.aliveList) {
            if(cliente.getName().equals(name)) {
                return cliente;
            }
        }
        return null;
    }
    public void addClient(String name, int limite)  {
        if (searchClient(name) != -1) {
            IO.println("fail: cliente ja existe");
            return;
        }
        this.aliveList.add(new Client(name, limite));
        this.sortAliveList();
    }

    public void give(String name, int value) throws Exception {
        Client cliente = getClient(name); 
        if(cliente == null) {
            //IO.println("fail: cliente nao existe");
            //return;
            throw new Exception("fail: cliente nao existe");
        }
        if (cliente.getBalance() + value > cliente.getLimite()) {
            // IO.println("fail: limite excedido");
            // return;
            throw new Exception("fail: limite excedido");
        }
        
        this.pushOperation(cliente, name, Label.GIVE, value);
    }

    public void take(String name, int value)  {
        Client cliente = getClient(name);
        this.pushOperation(cliente, name, Label.TAKE, value);
        
    }

    public void kill(String name) {
        int pos = searchClient(name);
        this.deathList.add( this.aliveList.remove(pos) );
        
        for (int i = 0; i < this.aliveOper.size(); i++) {
            Operation op = this.aliveOper.get(i);
            
            if(op.getName().equals(name)) {
                this.deathOper.add( this.aliveOper.remove(i) );
                i--;
            }
        }
    }

    public void plus() {
        for (Client client : this.aliveList) {
            this.pushOperation( client, client.getName(), Label.PLUS, (int) Math.ceil( 0.1*client.getBalance() ) );
        }
        // for (Client client : this.aliveList) {
        //     if ( client.getBalance() > client.getLimite() ) {
        //         this.kill( client.getName() );
        //     }
        // }
        for (int i=0; i<this.aliveList.size(); i++) {
            Client client = this.aliveList.get(i);
            if ( client.getBalance() > client.getLimite() ) {
                this.kill( client.getName() );
                i--;
            }
        }
    }

    @Override
    public String toString() {
        String ss = "";
        for ( Client client : this.aliveList ) {
            ss += ":) " + client.getName() + " " + client.getBalance() + "/" + client.getLimite() + "\n";
        }
        for ( Operation oper : this.aliveOper ) {
            ss += "+ " + oper + "\n";
        }
        for ( Client client : this.deathList ) {
            ss += ":( " + client.getName() + " " + client.getBalance() + "/" + client.getLimite() + "\n";
        }
        for ( Operation oper : this.deathOper ) {
            ss += "- " + oper + "\n";
        }
        return ss;
    }
}
