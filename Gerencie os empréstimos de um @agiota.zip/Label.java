public enum Label {
    GIVE,
    TAKE,
    PLUS;
  
    //private String descricao;
  
    //private Label(String descricao) {
    //  this.descricao = descricao;
  //}
  
    @Override
    public String toString(){
        switch (this.name()) {
            case "GIVE" :
                return "give";
            case "PLUS" :
                return "plus";
            case "TAKE" :
                return "take";
            default :
                return "";
        }
    }
}