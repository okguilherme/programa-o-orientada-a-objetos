import java.util.ArrayList;

class Client {
    private String name;
    private int limite;
    ArrayList<Operation> operations;

    public Client(String name, int limite) {
        this.name = name;
        this.limite = limite;
        this.operations = new ArrayList<>();
    }

    @Override
    public String toString() {
        String ss = this.name + " " + this.getBalance() + "/" + this.limite + "\n";
        for ( Operation oper : this.operations ) {
            ss += oper + "\n";
        }
        return ss;
    }

    public String getName() {
        return this.name;
    }
    public int getLimite() {
        return this.limite;
    }
    public ArrayList<Operation> getOperations() {
        return this.operations;
    }

    // public void addOperation(String name, Label label, int value) {
    //     this.operations.add( new Operation() );
    // }
    public void addOperation(Operation operation) {
        this.operations.add( operation );
    }
    
    
     //o quanto ele deve ao agiota
    // soma todas as operações de GIVE e PLUS
    // e subtrai todas as operações de TAKE 
    //quanto esta devendo
    public int getBalance() {
        int value = 0 ;
        for(Operation op : this.operations) {
            switch ( op.getLabel() ) {
                case GIVE :
                    value += op.getValue();
                    break;
                case PLUS :
                    value += op.getValue();
                    break;
                case TAKE :
                    value -= op.getValue();
                    break;
            }
        }
        return value;
    }
}
