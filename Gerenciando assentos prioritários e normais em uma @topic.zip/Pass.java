public class Pass {
    private int age;
    private String name;
    
    public Pass(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public int getAge() {
        return this.age;
    }
    public String getName() {
        return this.name;
    }
    public boolean isPriority() {
        if (this.age > 64) {
            return true;
        }
        return false;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String toString() {
        return name + ":" + age;
    }
}