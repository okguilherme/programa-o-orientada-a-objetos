public class Topic {
    private Pass [] prioritySeats;
    private Pass [] normalSeats;

    public Topic(int capacity, int qtdPriority) {
        prioritySeats = new Pass[qtdPriority];
        normalSeats = new Pass[capacity - qtdPriority];
    }
    
    public boolean insert(Pass pass) {
        if (findName(normalSeats, pass.getName()) == -1 && findName(prioritySeats, pass.getName()) == -1) {
            if(pass.isPriority()) {
                if (insert(prioritySeats, pass)){
                    return true;
                }
                else if (insert(normalSeats, pass)) { 
                    return true;
                }
                IO.println("fail: topic lotada");
                return false; 
            }
            else {
                if (insert(normalSeats, pass)){
                    return true;
                }
                else if (insert(prioritySeats, pass)) { 
                    return true;
                }
                IO.println("fail: topic lotada");
                return false;
            }
        }
        IO.printf("fail: %s ja esta na topic\n", pass.getName());
        return false;
    }
    
    public boolean remove(String nome) {
        // boolean retorno1 = remove(prioritySeats, nome);
        // boolean retorno2 = remove(normalSeats, nome);
        // return retorno1 || retorno2;


        // if ( remove(prioritySeats, nome) ) {
        //     return true;
        // } else if ( remove(normalSeats, nome) ) {
        //     return true;
        // }
        if ( remove(prioritySeats, nome) || remove(normalSeats, nome) ) {
            return true;
        }

        IO.println("fail: " + nome + " nao esta na topic");
        return false;
    }
    
    private int findFree(Pass [] list) {
        for (int i = 0; i < list.length; i++) {
            if (list[i] == null) {
                return i;
            }
        }
        return -1;
    }
    private int findName(Pass [] list, String name) {
        for (int i = 0; i < list.length; i++) {
            if (list[i] != null) {    
                if (list[i].getName().equals(name)) {
                    return i;
                }
            }
        }
        return -1;
    }
    private boolean insert(Pass [] list, Pass pass) {
        int num = findFree(list);
        if (num != -1) {
            list[num] = pass;
            return true;
        }
        return false;
    }
    private boolean remove(Pass [] list, String name) {
        int indice = findName(list, name);
        if (indice != -1) {
            list[indice] = null;
            return true;
        }
        return false;
    }
    public String toString() {
        int num = (prioritySeats.length) + (normalSeats.length);
        if (num < 0 ) {
            num = 0;
        }
        // String [] texto = new String [num];
        String txt = "[";
        
        for (int i = 0; i < prioritySeats.length; i++) {
            if (prioritySeats[i] == null) {
                // texto[i] = "@ ";
                txt += "@";
            }
            else {
                // texto[i] = "@" + prioritySeats[i].toString();
                txt += "@" + prioritySeats[i].toString();
            }
            txt += " ";
        }
        for (int j = 0; j < normalSeats.length; j++) {
            if (normalSeats[j] == null) {
                // texto[prioritySeats.length + j] = "= ";
                txt += "=";
            }
            else {
                // texto[prioritySeats.length + j] = "=" + normalSeats[j].toString();
                txt += "=" + normalSeats[j].toString();
            }
            if (j<normalSeats.length-1) {
                txt += " ";
            }
        }
        // for (int k = 0; k < texto.length; k++) {
        //     txt += texto[k];
        // }
        txt += "]";
        return txt;
    }
}
 