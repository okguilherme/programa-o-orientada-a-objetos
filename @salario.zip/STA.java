class STA extends Funcionario {
    protected int nivel;

    //inicializa nivel e muda maxDiarias para 1
    public STA(String nome, int nivel) {
        super(nome, 1);
        this.nivel = nivel;
        
    }
    
    public int getNivel() {
        return this.nivel;
    }

    //lógica do salário do sta
    //usa o super.getSalario() para pegar bonus e diarias
    @Override
    public int getSalario() {
        int salario = ( super.getSalario() + (3000 + 300 * this.nivel) );
        return salario;
    }

    // é acrescentado mais 300 de acordo com seu nível
    // salario = 3000 + 300 * nivel

    @Override
    public String toString() {
        return "sta:"+this.nome+":"+this.nivel + ":" + getSalario();
    }
}