import java.util.*;

class UFC {
    private Map<String, Funcionario> funcionarios = new TreeMap<>();

    @Override
    public String toString() {
        String txt = "";
        for( Funcionario f : funcionarios.values() ){
            txt += (f.toString()+"\n");
        }
        return txt;
    }

    public Funcionario getFuncionario(String nome) {
        return funcionarios.get(nome);
    }

    public void addFuncionario(Funcionario funcionario) {
        funcionarios.put(funcionario.getNome(), funcionario);
    }
    
    public void rmFuncionario(String nome) {
        funcionarios.remove(nome);
    }

    //reparte o bonus para todos os funcionarios
    public void setBonus(int bonus) {
        if ( this.funcionarios.size() == 0 ) {
            throw new MsgException("fail: sem funcionarios");
        }
        for ( Funcionario f : this.funcionarios.values() ) {
            f.setBonus( bonus / this.funcionarios.size() );
        }
    }
}








