class Terceirizado extends Funcionario {
    protected int horas;
    protected boolean isSalubre;

    public Terceirizado(String nome, int horas, String isSalubre) {
        super(nome, 0);
        this.horas = horas;
        this.isSalubre = isSalubre.equals("sim") ? true : false;
        
    }

    public int getHoras() {
        return this.horas;
    }

    public String getIsSalubre() {
        return isSalubre? "sim" : "não";
    }

    //lance uma MsgException com um texto diferente
    @Override
    public void addDiaria() {
        throw new MsgException("fail: terc nao pode receber diaria");
        
    }

    //lógica do salário do terceirizado. : salario = 4 * horas (+ 500 se insalubre)
    //usa o super.getSalario() para pegar bonus e diarias
    @Override
    public int getSalario() {
        int salario = ( super.getSalario() +  ( 4 * this.horas ) + ( this.isSalubre ? 500 : 0 ) );
        return salario;
    }

    @Override
    public String toString() {
        return "ter:"+this.nome+":"+ this.horas + ":" + (this.isSalubre ? "sim" : "nao") + ":" + getSalario();
    }
}