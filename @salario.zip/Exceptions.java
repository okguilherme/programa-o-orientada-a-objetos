
class MsgException extends RuntimeException {
    public MsgException(String message) {
        super(message);
    }
}



//porque utilizando o RuntimeException nao precisa diser no metodo que vai lansar uma 