import java.util.List;
import java.util.ArrayList;

public class Lapiseira {
    private float thickness; // calibre da lapiseira
    private Grafite tip;
    private List<Grafite> barrel;
    
    public Lapiseira (float thickness) {
        this.thickness = thickness;
        barrel = new ArrayList<>();
    }
    
    public boolean insert (Grafite grafite) {
        if (this.thickness != grafite.getThickness()) {
            IO.println("fail: calibre incompatível");
            return false;
        }

        barrel.add(grafite);
        return true;
    }
    public Grafite remove () {
        if (this.tip == null) {
            return null;
        }

        Grafite tip2 = this.tip;
        this.tip = null;
        return tip2;
    }
    public boolean pull () {
        if (tip != null) {
            IO.println("fail: ja existe grafite no bico");
            return false;
        }
        if (barrel.isEmpty()) {
            IO.println("fail: tambor vazio");
            return false;
        }

        tip = barrel.get(0);
        barrel.remove(0);
        return true;
    }
    public void writePage() {
        if (this.tip != null) {
            int tamanho = tip.getSize();
            int gasto = tip.usagePerSheet();
            
            if (tamanho <= 10 ) {
                IO.println("fail: tamanho insuficiente");
            }    
            else if (tamanho >= 10 + gasto) {
                tip.setSize(tamanho - gasto);
            }
            else if (tamanho > 10 && tamanho < 10 + gasto) {
                tip.setSize(10);
                IO.println("fail: folha incompleta");
            }
        }
        else {
            IO.println("fail: nao existe grafite no bico");
        }
    }
    
    public String toString() {
        String tambor = "";
        if (!barrel.isEmpty()) {
            for (int i = 0; i < barrel.size(); i++) {
                tambor += "[" + barrel.get(i) + "]";
            }
        }
        String saida = "calibre: " + thickness + ", bico: ";
        
        if (tip != null ) {
            saida += "[" + tip.toString() + "], ";
        }
        else {
            saida += "[], ";
        }
        if(!barrel.isEmpty()) {
            saida += "tambor: {" + tambor +"}";
        }
        else {
            saida += "tambor: {}";
        }
        return saida;
    }
    
}